Training / Test Data for Document Classification Task from POLCON Protest Book
==============================================================================

These labeled data are collected for newswire documents downloaded from the
LexisNexis data service. Each document has been manually labeled as
protest-relevant or protest-irrelevant. For more details, please consult

  Design and Methods of Semi-Automated Protest Event Analysis.
  Jasmine Lorenzini, Peter Makarov, and Bruno Wüest.
  In H. Kriesi, J. Lorenzini, B. Wüest and S. Husermann (eds.): The Return of
  Economic Protest in Times of Crisis: A 30 Countries Study.
  (Unpublished Manuscript)

The archive contains

* `polcon_book_binary_train.csv`
* `polcon_book_binary_test.csv`
* README.md

The .csv files have the following columns:

1. LexisNexis Identifier of the labeled document
2. Publication date of the document
3. Newswire service that has published the document
4. Label (0=Protest-Irrelevant, 1=Protest-Relevant)

Contact: Peter Makarov (makarov@cl.uzh.ch)

Licensed under CC-BY-4.0: https://creativecommons.org/licenses/by/4.0/
